from .source import main

__name__ == ['main']

